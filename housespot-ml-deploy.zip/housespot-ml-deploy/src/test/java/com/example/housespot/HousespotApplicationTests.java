package com.example.housespot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HousespotApplicationTests {

	@Test
	void contextLoads() {
	}

}
